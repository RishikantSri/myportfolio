<?php

return [
    'previous' => '&laquo;  पीछे',
    'next'     => 'आगे &raquo;',
];
