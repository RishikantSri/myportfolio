<?php

return [
    'site_title' => 'qaportfolio',
];
